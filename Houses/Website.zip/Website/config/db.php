<?php
    define('DB_SERVER', 'localhost');
    define('DB_USERNAME', 'root');
    define('DB_PASSWORD', '');
    define('DB_NAME', 'un_hr_kickoff');
    date_default_timezone_set('Asia/Manila');
?>